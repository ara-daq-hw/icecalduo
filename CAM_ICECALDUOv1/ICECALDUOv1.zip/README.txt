ICECALDUOv1.GTL: Top Copper
ICECALDUOv1.GL2: Inner Layer 2
ICECALDUOv1.GL3: Inner Layer 3
ICECALDUOv1.GBL: Bottom Copper
ICECALDUOv1.GTO: Top Silkscreen
ICECALDUOv1.GTS: Top Soldermask
ICECALDUOv1.GBO: Bottom Silkscreen
ICECALDUOv1.GBS: Bottom Soldermask
ICECALDUOv1.TXT: NC Drill
